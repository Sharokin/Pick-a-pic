<?php 
    
    function connect(){

        $serverName = "sql.okej.lol";
        $login = array(  "UID" => "SA",  "PWD" => "Sqladminpass123!",  "Database" => "ProdDB");
        $conn = sqlsrv_connect($serverName, $login);

        if( $conn === false ) {
            echo "Could not connect.\n";
            die( print_r( sqlsrv_errors(), true));
        }

        return $conn;
    }

    function disconnect($conn){
        sqlsrv_close($conn);
    }

    //need to download the microsoft server driver for this to work.

?>


<!-- 
    IP: sql.okej.lol
    USER: SA
    PASS: Sqladminpass123! 
-->