<?php 
/*
bio
prof pic
*/
    session_start();
       
    include('connection.php');
    include('connect.php');       
    if(!isset($_SESSION['username']))
    {
        header("Location:login.php");
    } 

    $username_ = $_SESSION['username'];            
    $checkSql = "SELECT fullname, bio FROM users WHERE username = '$username_'";
    $execute = $connection->query($checkSql);  
    $row = $execute->fetch_assoc();                     
    $oldBio = $row['bio'];
    $oldFullname = $row['fullname'];

    $check = true;

    if (isset($_POST['delete']))
    {
        $sqlPrep = $connection->prepare("DELETE FROM users WHERE username = ?;");

        $sqlPrep->bind_param("s", $username_);
        if ($sqlPrep->execute())
        {            
            header("Location:logout.php");                  
        } 
        else
        {
            echo "<script>alert('Failed to delete account')</script>";
        }                          
    } 
    if (isset($_POST['submit'])) //submit button pressed
    {
        
        $newPassword = $_POST['newPass'];        
        $oldPassword = $_POST['oldPass'];        

        $bio = $_POST['bio'];
        if (!empty($_POST['username'])) //username not empty
        {
            $newUsername = $_POST['username'];
        }
        else
        {
            echo "<script>alert('Type in your username')</script>";
            $check = false;
        }
        
        if (!empty($_POST['fullname'])) //fullname not empty
        {
            $fullName = $_POST['fullname'];
        }
        else
        {
            echo "<script>alert('Type in your Full Name')</script>";
            $check = false;
        }

        if (strlen($_POST['newPass'])>=6 || strlen($_POST['newPass'])==0) //password empty or 6 charachters and longer (acceptable)
        {                        
            $encryptedNewPass = password_hash($newPassword, PASSWORD_BCRYPT);
        }
        else
        {
            echo "<script>alert('Password needs to be 6 characters or more.')</script>";
            $check = false;
        }

        function loadProfilePic($newUsername, $username_)
        {
            $conn = connect();
            
            /* saving the new profile pic to the folder */
            $folder = "../img/profile/";
            // $image_extension = strtolower(pathinfo($_FILES["profile_pic"]["name"], PATHINFO_EXTENSION));
            // $named_image = $folder . $newUsername . "." . $image_extension;
            $named_image = $folder . $newUsername . ".jpg";     //changed to only jpg types for simplicity's sake. will change to webp when that function is ready

            move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $named_image);

            /* saving the path of the profile picture to db */

            $query = mysqli_prepare($conn, "UPDATE users SET profile_img_path = ? WHERE username = ?");
            mysqli_stmt_bind_param($query, "ss", $named_image, $newUsername);
            mysqli_stmt_execute($query);

            if($newUsername !== $username_){   
                unlink("../img/profile/" . $username_ . ".jpg");  // deletes the old profile picture
            }

            disconnect($conn);
        }

        function renameProfilePic($newUsername, $username_){
            // if no new profile pic is added but a the username is changed
            // we need to rename the old profile pic and change its path so it matches
            // the new username.
            if($newUsername !== $username_) {

                echo "<script> console.log('usernames were NOT the same');</script>";

                if(file_exists("../img/profile/" . $username_ . ".jpg")) {  // don't think this is necessary, but will keep it here for further testing 
                
                    $conn = connect();

                    echo "<script> console.log('connected to db');</script>";
                
                    if(rename("../img/profile/" . $username_ . ".jpg", "../img/profile/" . $newUsername . ".jpg")){

                        $img_name = "../img/profile/" . $newUsername . ".jpg";
                
                        $query = mysqli_prepare($conn, "UPDATE users SET profile_img_path = ? WHERE username = ?");
                        mysqli_stmt_bind_param($query, "ss", $img_name, $newUsername);
                        mysqli_stmt_execute($query);


                    } else die("Could not rename profile picture to " . $newUsername . ".jpg" . $conn->error);

                    disconnect($conn);
                    echo "<script> console.log('disconnected to db');</script>";

                }

            } else { 
                echo "<script> console.log('usernames were the same');</script>";
            }
        }

        if($check) //got trough all the previous checks (so far so good)
        {
        
            $checkSql = "SELECT username FROM users WHERE username = '$newUsername'";
            $execute = $connection->query($checkSql);            
            $row = $execute->fetch_assoc();     

            if ($execute->num_rows > 0 && strcmp($newUsername, $username_) != 0) //user tried to change to an existing username
            {
                echo "<script>alert('Username taken!')</script>";
                $check = false;                
            }
            
            $query = "SELECT * FROM users WHERE username='$username_' ";
            $execute = $connection->query($query);            
            $row = $execute->fetch_assoc();            
            $encryptedPassDb = $row['password'];

            if(!password_verify($oldPassword, $encryptedPassDb) && strlen($oldPassword)>0) //user entered wrong old password
            {                    
                echo "<script>alert('Wrong old password!')</script>";
                $check = false;        
            }          
            else if(strlen($oldPassword)==0 && strlen($newPassword)!=0) //user tried to change password without entering old password
            {
                echo "<script>alert('Enter old password to change it!')</script>";
                $check = false;        
            }            
            else if(strlen($newPassword)==0) //user wants to change info but not password
            {
                $sqlPrep = $connection->prepare("UPDATE users SET username = ?, fullname = ?, bio = ? WHERE username = ?;");

                $sqlPrep->bind_param("ssss", $newUsername, $fullName, $bio, $username_);
                if ($sqlPrep->execute())
                {
                    $_SESSION['username'] = $newUsername;
                    if(empty($_FILES["profile_pic"]["name"]) && $newUsername !== $username_) {
                        echo "<script> console.log('first case');</script>";
                        renameProfilePic($newUsername, $username_);
                    } else {
                        loadProfilePic($newUsername, $username_);
                    }
                    header("Location:settings.php");
                }
                else
                {
                    die("Error! " . $connection ->error);
                }

            }
            else if($check == true) //user wants to change password and info
            {
                $sqlPrep = $connection->prepare("UPDATE users SET username = ?, fullname = ?, password = ?, bio = ? WHERE username = ?;");

                $sqlPrep->bind_param("sssss", $newUsername, $fullName, $encryptedNewPass, $bio, $username_);
                if ($sqlPrep->execute())
                {
                    $_SESSION['username'] = $newUsername;
                    if(empty($_FILES["profile_pic"]["name"]) && $newUsername !== $username_) {
                        echo "<script> console.log('second case');</script>";
                        renameProfilePic($newUsername, $username_);
                    } else {
                        loadProfilePic($newUsername, $username_);
                    }
                    header("Location:settings.php");
                }
                else
                {
                    die("Error! " . $connection ->error);
                }
            }
			header("Refresh:0");
        } 
    }                    
                 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pick a Pic - Settings</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="../js/navbar_injection.js"></script>
    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
    <link rel="stylesheet" type="text/css" href="../style/main.css">
    <link rel="stylesheet" href="../style/registrate.css">
	
	<meta Http-Equiv="Cache-Control" Content="no-cache">
	<meta Http-Equiv="Pragma" Content="no-cache">
	<meta Http-Equiv="Expires" Content="0">
	<meta Http-Equiv="Pragma-directive: no-cache">
	<meta Http-Equiv="Cache-directive: no-cache">
</head>

<body>
    
    <nav>
        <!-- navbar goes here with js script -->
    </nav>

    <div class="center__section color3">

        <div class="signup__label__container">
            <h1>Change Account Information</h1>
        </div>
        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data" class="signup__form">

            <div class="form__element__settings">
                <div class="form__container__settings">
                    <label class="form__label__profile">Change Profile Pic</label>
                    <input name="profile_pic" type="file" class="form__input__profile">
                </div>
            </div>

            <div class="form__element__settings">
                <div class="form__container__settings">
                    <input name="fullname" type="text" value="<?php echo $oldFullname?>" class="form__input">
                    <label class="form__label">New Full Name</label>
                </div>
            </div>

            <div class="form__element__settings">
                <div class="form__container__settings">
                    <input name="username" type="text" value="<?php echo $username_?>" class="form__input">
                    <label class="form__label">New Username</label>
                </div>
            </div>

            <div class="form__element__settings">
                <div class="form__container__settings">
                    <input name="bio" id="settings__bio" type="" value="<?php echo $oldBio?>" class="form__input">
                    <label class="form__label">New Bio</label>
                </div>
            </div>

            <div class="form__element__settings">
                <div class="form__container__settings">
                    <input name="oldPass" type="password" class="form__input">
                    <label class="form__label">Old Password</label>
                </div>
            </div>
            <div class="form__element__settings">
                <div class="form__container__settings">
                    <input name="newPass" type="password" class="form__input">
                    <label class="form__label">New Password</label>
                </div>                
                <div class="signup__link__container">
                    <button type="submit" name="submit" class="form__submit">Submit</button>                
                </div>
                <div class="signup__link__container">
                     <button type="submit" name="delete" onclick="return confirm('Are you sure you want to delete the account?')" class="form__submit__delete">Delete account</button>
                </div>                                                         
        </form>
    </div>
</body>

</html>