<?php 
session_start();
include('connection.php');
if (isset($_SESSION['username'])) {
    header('Location: feed_main.php');
}

$password = null;
$username = null;
$pass__err="";
$user__err="";
$public_key = "6LdwMKUiAAAAAJp7x_VLAhY7AXi688OAHSBrsFU-"; //site key
$private_key = "6LdwMKUiAAAAAEFiMngHusasC2nHO0d1gy8xAG8A"; //secret key
$url = "https://www.google.com/recaptcha/api/siteverify";
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query = "SELECT * FROM users WHERE username='$username' ";
    $execute = $connection->query($query);

    //i am not a robot code V V V V V V V V V V V V V

    
    $response_key = $_POST['g-recaptcha-response'];
    $response = file_get_contents($url.'?secret='.$private_key.'&response='.$response_key);
    $response = json_decode($response);

    //i am not a robot code ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^

    
    if ($execute->num_rows > 0) {
        while ($row = $execute->fetch_assoc()) {
            $encryptedPassDb = $row['password'];
            if(password_verify($password, $encryptedPassDb))
            {
                if($response->success == 1)
                {
                    $_SESSION["username"] = $username;
                    header("Location:feed_main.php");
                }
                else
                {
                    echo "<script>alert('Confirm that you are not a robot!')</script>";
                }
            }else{

                $pass__err = "Wrong password!";
            }
        }
    }else {
        $user__err ="This account does not exist";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/registrate.css?v=<?php echo time(); ?>">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
    <title>Pick a Pic - Login</title>
</head>

<body>
    <div class="main__reg__container">
        <section class="logo__section">
            <div class="logo__container">
                <img src="../img/icons/logo.png" alt="logo" id="logo__img">
            </div>
        </section>


        <div class="login__form__container">

            <form class="login__form" action="" method="post" id="reg__form">
                <div class="login__label__container form__element">
                    <h1>Log In</h1>
                </div>
                <div class="form__element">
                    <div class="form__container">
                        <input value="<?php echo $username ?>" required type="text" name="username" class="form__input">
                        <label class="form__label">Username</label>
                        <span class="error_msg" id="username__err"><?php echo $user__err ?></span>
                    </div>

                </div>
                <div class="form__element">
                    <div class="form__container">
                        <input value="<?php echo $password ?>" required type="password" name="password"
                            class="form__input">
                        <label class="form__label">Password</label>
                        <span class="error_msg" id="pass__err"><?php echo $pass__err ?></span>
                    </div>
                    <div class="signup__link__container">
                        <p>Don't have an account?&nbsp;<a href="login_register.php">Sign Up</a></p>
                    </div>
                </div>

                <div class="g-recaptcha" data-sitekey="<?php print $public_key; ?>"></div>
                <!-- //i am not a robot code -->

                <div class="form__element">
                    <div class="form__submit__container">
                        <button type="submit" id="" name="submit" class="form__submit">Log In</button>
                    </div>
                </div>
            </form>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script> <!-- //i am not a robot code -->
        </div>

    </div>
    <script src="../js/registrate.js?v=<?php echo time(); ?>"></script>
</body>

</html>