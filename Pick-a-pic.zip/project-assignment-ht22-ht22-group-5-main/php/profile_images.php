<?php 

    header('Content-Type: application/json; charset=utf-8');
    
    session_start();
    include('connection.php');


$username = $_GET['username'];

$sqlStr = "SELECT * FROM posts WHERE userID = '$username'";
$execute = $connection->query($sqlStr);
$array = array();

while($row = $execute->fetch_assoc())
    {
        $array[]= $row;
    }

    $array = json_encode($array);

echo $array;

?>