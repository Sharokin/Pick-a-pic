<?php
    session_start();
    include('connection.php');

    $userID = $_POST['userID'];
    $postID = $_POST['postID'];
    $comment = $_POST['comment'];

    if(!empty($comment))
    {
        $sqlStr = "INSERT INTO comments (userID, postID, comment) VALUES ('$userID', '$postID','$comment')";
    $result = mysqli_query($connection, $sqlStr);

    if ($result) {
        echo 1;
    }else {
        echo 0;
    }
    }else{
        echo 0;
    }


    
    
    
?>