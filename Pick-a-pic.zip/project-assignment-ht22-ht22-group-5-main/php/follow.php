<?php 
session_start();
include('connection.php');
if(!isset($_SESSION['username']))
{
    header("Location:login.php");
}


$followerID = $_SESSION['username'];
if (isset($_GET['username'])){

    $userID = $_GET['username'];

}

$checkSql = "SELECT * FROM followers WHERE userID = '$userID' AND followerID ='$followerID'";
$execute = $connection->query($checkSql);

    if ($execute->num_rows > 0) {
        header("Location:profile.php?username=$userID");
    } else{
        $sqlPrep = $connection->prepare("INSERT INTO followers (userID,followerID) values (?,?);");

$sqlPrep->bind_param("ss",$userID, $followerID);

if ($sqlPrep->execute())
    {
        
        header("Location:profile.php?username=$userID");
    }else{
        die("Error! " . $connection ->error);
    }
    }





?>