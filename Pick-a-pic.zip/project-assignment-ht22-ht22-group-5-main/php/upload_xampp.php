<?php
    session_start();
    include 'connect.php';

    function uploadImage(){
        $conn = connect();
        
        echo "<style> console.log(" . 1 . ")</style>";

        $userID = $_SESSION['username'];
        $caption = $_POST['caption'];
        $image_id = "";

        /* INSERT using mysqli for Xampp  */
        $query_x = mysqli_prepare($conn, "INSERT INTO posts (userID, caption) VALUES(?,?)");
        mysqli_stmt_bind_param($query_x, "ss", $userID, $caption);
        
        if(mysqli_stmt_execute($query_x)){
            //fetch last inserted ID here
            $image_id = mysqli_insert_id($conn);
            echo "<style> console.log(" . 2 . ")</style>";
        } else {
            echo "<style> console.log(" . "die" . ")</style>";
            die(print_r("Error description: " . $conn -> error));
        }

        /*
            -TODO-
            Use $image_id to name the picture and upload it to "server"-folder using mysqli
        */
        

        $folder = "../img/posts/";
        $image_extension = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
        $named_image = $folder . $image_id . "." . $image_extension;

        move_uploaded_file($_FILES["file"]["tmp_name"], $named_image);

        // going to add error handling and the like later.
        echo "<style> console.log(" . 3 . ")</style>";
        disconnect($conn);

    }

    if(isset($_POST['uploadImageAndCap'])){
        uploadImage();
    }

?>