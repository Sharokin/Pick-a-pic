<?php
    
    // Xampp database configuration using functions

    function connect() {
        $dbhost = "localhost";
        $dbuser = "root";       
        $dbpass = "";         
        $db = "proddb";

        $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n". $conn -> error);
    
        return $conn;
    }
    
    function disconnect($conn) {
        $conn -> close();
    }

?>
