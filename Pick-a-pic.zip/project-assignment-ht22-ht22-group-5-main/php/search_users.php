<?php
	include('connect.php');
	session_start();
	$conn = connect();
	$user = $_POST['user'];

	$input = $user . "%";
	$query = mysqli_prepare($conn, "SELECT username FROM users WHERE username LIKE ?");
	mysqli_stmt_bind_param($query, "s", $input);
	mysqli_stmt_execute($query);
	$result = mysqli_stmt_get_result($query);
	$array = $result->fetch_all(MYSQLI_ASSOC);
	echo json_encode($array);
	$conn->close();
?>

