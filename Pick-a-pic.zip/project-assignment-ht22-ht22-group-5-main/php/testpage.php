<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Title</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script>
			$(document).ready(function(){
				$('nav').load("nav.php");
			});
		</script>
	</head>
	<body>
		<nav>
			<!-- Navbar loaded here! -->
		</nav>
	</body>
</html>