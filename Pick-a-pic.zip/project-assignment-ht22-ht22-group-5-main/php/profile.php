<?php 
session_start();
include('connection.php');

if (!isset($_GET['username']))
{
    header("Location:feed_main.php");
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../style/main.css?v=<?php echo time(); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <?php 
        

        if (isset($_SESSION['username']))
        {
            echo '<script type="text/javascript" src="../js/navbar_injection.js"></script>';
        }

    ?>

    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
    <title>Pick a Pic - Profile</title>
</head>

<body>

    <nav>
        <!-- navbar goes here with js script -->
    </nav>


    <div class="main__container">
        <section class="profile__section">

            <div class="profile__items__container">
                <div class="profile__picture__contaier">
                    <?php 
                    if (isset($_GET['username']))
                    {
                        $username = $_GET['username'];
                        

                        $sqlStr = "SELECT * FROM users WHERE username='$username'";
                        $execute = $connection->query($sqlStr);
                        
                        $row = $execute ->fetch_assoc();

                        $fullname = $row['fullname'];
                        $bio = $row['bio'];
                        $pfp_path = $row['profile_img_path'];

                    }
                    
                    ?>
                    <img src="<?php 

                    if(empty($pfp_path) || $pfp_path == NULL || $pfp_path == "")
                    {
                        echo '../img/icons/default-icon-temp2.png';
                    }else{
                        echo $pfp_path;
                    }
                    
                    
                     ?>" alt="profile_pic.jpg">

                    <?php 

                    if (isset($_GET['username']))
                    {
                       
                        
                        echo "<h1 id='label__fullname'>". $fullname ."</h1>";
                        echo "<p id='label__username'>@". $username ."</p>";

                        if(isset($_SESSION['username']))
                        {
                        $sessionUser = $_SESSION['username'];
                        
                        if($_GET['username'] != $_SESSION['username'])
                        {
    
                            $sqlStr = "SELECT * FROM followers WHERE userID = '$username' AND followerID ='$sessionUser'";
                            $execute = $connection->query($sqlStr);
    
                            if ($execute->num_rows > 0) {
                                echo '<button class="follow__btn" onclick="location.href=\'unfollow.php?username='.$username.'\'">Unfollow</button>';
                            }else{
                                echo '<button class="follow__btn" onclick="location.href=\'follow.php?username='.$username.'\'">Follow</button>';
                            }
                            
                        }
                    }
                        
                    }
                    ?>
                    <!-- <h1 id="label__fullname">Full Name</h1>-->
                    <!--<p id="label__username">@username</p>-->

                </div>
                <div class="profile__description__container">
                    <div class="following__container">

                        <p id="following__link">Following</p>
                        <p id="followers__link">Followers</p>
                    </div>

                    <?php 
                         echo "<p>". $bio ."</p>";
                    ?>
                </div>
            </div>

        </section>

        <!-- GALERY GRID -->
        <section class="images__section" id="images__section">

            <!-- <div class="images__grid" id="profile_images_grid">


                <div class="grid__item">
                    <div class="images__post">
                        <img src="../img/jaguar.jpg" alt="">

                        <div class="pop__up__description">
                            <div class="pop__up__likes">
                                <p>123 likes</p>
                            </div>
                            <p>Wow so cool lmaooo yo aay relax fr frow so cool lmaooo yo aay relax fr frow so cool
                                lmaooo yo aay relax fr frow so cool lmaooo yo aay relax fr frow so cool lmaooo yo aay
                                relax fr fr</p>
                        </div>

                    </div>
                </div>

            </div> -->
        </section>
    </div>

    <!-- FOLLOWERS POP UP DIV -->
    <div class="followers__cover">
        <div class="followers__popup">
            <div class="followers__header">
                <span></span>
                <p>Followers</p>
                <span id="close__follower__popup">x</span>
            </div>
            <div class="all__followers" id="all__followers">

            </div>
        </div>
    </div>

    <!-- FOLLOWING POP UP DIV -->

    <div class="following__cover">
        <div class="following__popup">
            <div class="following__header">
                <span></span>
                <p>Following</p>
                <span id="close__following__popup">x</span>
            </div>
            <div class="all__following" id="all__following">

            </div>
        </div>
    </div>



    <script src="../js/followers_list.js?v=<?php echo time(); ?>"></script>
    <script src="../js/following_list.js?v=<?php echo time(); ?>"></script>
    <script src="../js/image_gallery.js?v=<?php echo time(); ?>"></script>
    <script src="../js/profile.js?v=<?php echo time(); ?>" defer></script>
</body>

</html>