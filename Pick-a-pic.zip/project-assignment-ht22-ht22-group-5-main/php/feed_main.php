<?php 
session_start();
include('connection.php');

//include('script_load_feed.php');

if (!isset($_SESSION['username']))
{
    header("Location:login.php");
}
?>

<!--SHAROKIN-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pick a Pic - Main Feed</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="../js/navbar_injection.js"></script>
    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
    <link rel="stylesheet" type="text/css" href="../style/main.css?v=<?php echo time(); ?>">
</head>

<body>
    
    <nav>
        <!-- navbar goes here with js script -->
    </nav>

    <div id="feed" class="center__section color3" onscroll="append_load_feed_follow_check()" on>
        
    </div>

    <script>
        var load = 0;
        var feed = document.getElementById("feed");
        feed.scrollTo(0, 0);

        function append_load_feed_follow(){
            var request = new XMLHttpRequest();
            request.onreadystatechange = function(){
                if (this.readyState == 4 && this.status == 200){
                    feed.innerHTML += this.responseText;
                }
            };
            let q_user="<?php echo $_SESSION['username'] ?>";
            let q_load=load;
            let q="user="+q_user+"&load="+q_load;
            request.open("GET", "script_load_feed.php?"+q, true);
            request.send();
            ++load;
            if (document.getElementById("eof") == null)
                generate_text_to_img();
        }

        var h = document.body.clientHeight;
        document.body.onresize = function seth(){h = document.body.clientHeight};
        
        function append_load_feed_follow_check(){
            console.log(feed.scrollTop, feed.scrollHeight, feed.scrollTop >= feed.scrollHeight - (h));
            if (document.getElementById("eof") != null) {feed.onscroll = null; }
            if (feed.scrollTop >= feed.scrollHeight - (h)){
                append_load_feed_follow();
            }
        }

        async function generate_text_to_img(text){
            api_url = "https://motivational-quote-api.herokuapp.com/quotes/random"
            const url = new URL(api_url);
            const response = await fetch(url);
            const quote = await response.json();

            var canvas = document.createElement('canvas'); //document.getElementById(canvas_id);
            canvas.width = "800";
            canvas.height = "800";
            var pen = canvas.getContext("2d");
                

            pen.fillStyle = "#000000";
            pen.fillRect(0, 0, canvas.width, canvas.height);
                
            var words = quote.quote.split(' ');
            let word_n = words.length;

            let em = (canvas.width*0.9)/20;

            var rows = [];
            let row_n = 0;
            rows[row_n] = "";
            for (word_i = 0; word_i < word_n; word_i++){
                if (rows[row_n].length + words[word_i].length > em){
                    row_n++;
                    rows[row_n] = "";
                }
                rows[row_n]+=words[word_i]+" ";
            }
            rows[++row_n] = "- "+quote.person;

            pen.textAlign = "center";
            pen.fillStyle = "#ffffff";
            pen.font = em+"px Comic Sans MS";
            for (r = 0; r < row_n; r++){                    
                pen.fillText(rows[r], (canvas.width/2), (canvas.height/2) + (-row_n/2+r*1.5)*em, canvas.width-(2*em));
            }
            pen.fillText(rows[row_n], (canvas.width/2), (canvas.height/2) + (-row_n/2+row_n+2.5)*em, canvas.width-(2*em));
            var post = document.createElement('div');
            post.classList.add("post");
            post.classList.add("color1");

            var link = document.createElement('a');
            link.target ="_blank";
            link.href = "https://motivational-quote-api.herokuapp.com/";
            post.appendChild(link);

            var post_frame = document.createElement('div');
            post_frame.classList.add("post__frame");
            link.appendChild(post_frame);

            var image = document.createElement('img');
            image.classList.add("post__frame__picture");
            image.src = canvas.toDataURL();
            image.alt = link.href;
            post_frame.appendChild(image);

            var post_description = document.createElement('div');
            post_description.classList.add('post__description');
            post_description.classList.add('post__comments');
            post.appendChild(post_description);

            var credits = document.createElement('a');
            credits.innerHTML = "By Zainabu Malabu";
            credits.href = link.href;
            credits.target = "_blank";
            post_description.appendChild(credits);

            feed.appendChild(post);
        }

        document.onload = append_load_feed_follow();
    </script>
</body>

</html>