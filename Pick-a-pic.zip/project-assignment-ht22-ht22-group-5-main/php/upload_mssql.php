<?php
    include 'MSSQLconn.php';

    function uploadImage(){
        $conn = connect();

        $userID = $_SESSION['username'];
        $caption = $_POST['caption'];
        $image_id = "";

        /* INSERT using sqlsrv for MSSQL server */
        $query_srv = "INSERT INTO dbo.posts (userID, caption) VALUES(?, ?)";
        $param_srv = array($userID,$caption);                       
        $result_srv = sqlsrv_query($conn, $query_srv, $param_srv);
        if( $result_srv === false ) {
            die( print_r(sqlsrv_errors(), true));
        } else {
            $id_query = "SELECT SCOPE_IDENTITY() as id";
            $result_of_id_query = sqlsrv_query($conn, $id_query);

            while($row = sqlsrv_fetch_object($result_of_id_query)) {
                $image_id = $row['id']; //not sure if this is how it is done. Need to look it up
            }
        }

        /*
            -TODO-
            Use $image_id to name the picture and upload it to "server"-folder using sqlsrv
        */
        
        //rename image, then use imagewebp() to convert it.
        
        //imagewebp();
        

        $folder = "../img/posts/";
        $image_extension = strtolower(pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION));
        $named_image = $folder . $image_id . $image_extension;

        move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $named_image);

        // going to add error handling and the like later.

        disconnect($conn);

}

?>