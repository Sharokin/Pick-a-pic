<?php 
session_start();
include('connection.php');
if(!isset($_SESSION['username']))
{
    header("Location:login.php");
}


$followerID = $_SESSION['username'];
if (isset($_GET['username'])){

    $userID = $_GET['username'];

}

$checkSql = "SELECT * FROM followers WHERE userID = '$userID' AND followerID ='$followerID'";
$execute = $connection->query($checkSql);

    if ($execute->num_rows > 0) {

        $sqlStr = "DELETE FROM followers WHERE userID = '$userID' AND followerID ='$followerID'";
        $execute = $connection->query($sqlStr);
        
        header("Location:profile.php?username=$userID");

    } else{
        header("Location:profile.php?username=$userID");
}





?>