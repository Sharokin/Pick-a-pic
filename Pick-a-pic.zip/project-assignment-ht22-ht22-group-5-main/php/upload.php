<?php 
session_start();
include 'connect.php';

echo "<script> console.log(". 1 .")</script>";

if(!isset($_SESSION['username']))
{
    header("Location:login.php");
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../style/main.css?v=<?php echo time(); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="../js/navbar_injection.js"></script>
    <title>Pick a Pic - Upload</title>
    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
</head>

<body>

    <nav>
        <!-- navbar goes here with js script -->
    </nav>

    <script>
        // When the user clicks on <div>, open the popup
        function myFunction() {
            var popup = document.getElementById("myPopup");
            popup.classList.toggle("show");
        }
    </script>
    <div class="center__section__upload color3">
        <div class="upload">
            <form method="POST" name="form" id="form" enctype="multipart/form-data">
                <h1 class="upload__title__mobile">Upload</h1>
                    <div id="canvas_size">
                        <canvas id="test_canvas" height="1024" width="1024"/></canvas>
                        <div id="choose">
                            <div class="inner"><h1 class="upload__title">Upload</h1></div>
                            <div class="inner"><label for="input_file">Pick a Pic...</label><input type="file" name="file" id="input_file"/></div>
                            <div class="inner"><textarea maxlength="100" name="caption" class="upload__caption" id="caption" cols="30"
                                placeholder="Add Caption..."></textarea></div>
                            <div class="inner"><input type="submit" name="submit" id="submit"/></div>
                        </div>
                    </div>
                </div>
                <textarea name="base64" id="base64"></textarea>
            </form>
        </div>
    </div>

    <?php


        function uploadImage(){
            
            $conn = connect();

            $userID = $_SESSION['username'];
            $caption = $_POST['caption'];
            $image_id = "";

            /* INSERT using mysqli for Xampp  */
            $query_x = mysqli_prepare($conn, "INSERT INTO posts (userID, caption) VALUES(?,?)");
            mysqli_stmt_bind_param($query_x, "ss", $userID, $caption);
            
            if(mysqli_stmt_execute($query_x)){
                //fetch last inserted ID here
                $image_id = mysqli_insert_id($conn);
            } else {
                die(print_r("Error description: " . $conn -> error));
            }

            $imageBase64 = $_POST['base64'];
            $base_to_php = explode(',', $imageBase64);
            $data = base64_decode($base_to_php[1]);
            $folder = "../img/posts/";
            file_put_contents($folder . $image_id . ".webp", $data);

            disconnect($conn);

        }

        if(isset($_POST['submit'])) {
            uploadImage();
            header('Location: feed_main.php');
        }
    ?>

</body>

<script type="text/javascript" src="../js/canvas_preview.js"></script>

</html>