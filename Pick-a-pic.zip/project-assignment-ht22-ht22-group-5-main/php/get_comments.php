<?php
    session_start();
    include('connection.php');

    $postID = $_POST['postID'];
    $sqlStr = "SELECT * FROM comments WHERE postID ='$postID' ORDER BY id ASC ";
    $result = mysqli_query($connection, $sqlStr);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
?>

<div class="comment__container">

    <p class="comment__txt">
        <a class="comment__username" href="../php/profile.php?username=<?php echo $row['userID']; ?>">
            <?php echo $row['userID']; ?>:&nbsp;
        </a>

        <?php echo $row['comment'];?>

    </p>
</div>

<?php } } ?>