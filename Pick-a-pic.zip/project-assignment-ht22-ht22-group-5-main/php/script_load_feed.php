<?php
    include('connect.php');

    function tech_html($text){
        echo '<h1 class="tech__msg">'.$text.'</h1>';
    }

    function html_eof(){
        echo '<span id="eof"></span>';
    }

    function promoted_html($post_user, $post_title, $post_picture, $post_link){
        echo '<div class="post color1">';
        echo '<a href="' . $post_link . '" target="_blank">';
        echo '<div class="post__frame"><img class="post__frame__picture" src="../img/posts/' . $post_picture . '.webp" alt="' . $post_picture . '" ></div>';
        echo '</a>';
        echo '<div class="post__description">';
        echo '<p class="">By <a href="'.$post_link.'" target="_blank">' . $post_user . '</a></p>';
        echo '<p class="">' . $post_title . '</p>';
        echo '</div>';
        echo '</div>'; 
    }

    function quote_html($id){
        echo '<div class="post color1">';
        echo '<a href="' . "https://motivational-quote-api.herokuapp.com/" . '" target="_blank">';
        echo '<div class="post__frame"><canvas id="quote_'.$id.'" class="post__frame__picture" width="600" height="600"></canvas></div>';
        echo '</a>';
        echo '<div class="post__description">';
        echo '<p class="">By <a href="'. "https://motivational-quote-api.herokuapp.com/". '" target="_blank">' . "Zainabu Malabu" . '</a></p>';
        echo '<p class="">' . "Motivational Quote" . '</p>';
        echo '</div>';
        echo '<script> generate_quote("quote_"'.$id.') </script>';
        echo '</div>'; 
    }

    function post_html($post_user, $post_title, $post_picture, $post_date){
        echo '<div class="post color1">';
        echo '<a href="singular_post.php?id=' . $post_picture . '" target="_blank">';
        echo '<div class="post__frame"><img class="post__frame__picture" src="../img/posts/' . $post_picture . '.webp" alt="' . $post_picture . '" ></div>';
        echo '</a>';
        echo '<div class="post__description">';
        echo '<p class="">By <a href="profile.php?username='.$post_user.'">@' . $post_user . '</a> at ' . $post_date . '</p>';
        echo '<p class=""><a href="singular_post.php?id=' . $post_picture . '">' . $post_title . '</a></p>';
        echo '<a href="singular_post.php?id=' . $post_picture . '" target="_blank">[comments]</a>';
        echo '</div>';
        echo '</div>';    
    }

    function load_feed_custom($c_user, $c_title, $c_img){
        post_html($c_user, $c_title, $c_img, date("Y-m-d h:i:s"));
    }

    function load_single($img_id){
        $conn = connect();

        $q_post="SELECT * FROM `posts` WHERE `imageID`='$img_id'";
        $r_post = $conn->query($q_post);
        
        $conn = connect();
        $r_post = $conn->query($$q_post);
        
        while($post = $r_post->fetch_assoc()){
            $post_picture=$post['imageID']; //to .webp
            //$post_picture="../img/posts/" . $post_picture . ".jpg";
            $post_user=$post['userID'];
            $post_title=$post['caption'];
            $post_date=$post['dateOfUpload'];
            
            post_html($post_user, $post_title, $post_picture, $post_date);
        }
        disconnect($conn);
    }

    function load_feed_full($load_n, $post_n){
        $number_of_posts=$post_n;
        $offset=$number_of_posts*$load_n;
        $posts_loaded_n = 0;

        $conn = connect();
        $q_post="SELECT * FROM `posts` ORDER BY `imageID` DESC LIMIT $number_of_posts OFFSET $offset";
        $r_post = $conn->query($q_post);

        while($post = $r_post->fetch_assoc()){
            $posts_loaded_n++;
            $post_picture=$post['imageID']; //to .webp
            //$post_picture="../img/posts/" . $post_picture . ".jpg";
            $post_user=$post['userID'];
            $post_title=$post['caption'];
            $post_date=$post['dateOfUpload'];
            
            post_html($post_user, $post_title, $post_picture, $post_date);
        }
        disconnect($conn);
        return $posts_loaded_n;
    }

    function load_feed_follow($load_n, $post_n, $user){
        $number_of_posts=$post_n;
        $offset=$number_of_posts*$load_n;
        $posts_loaded_n = 0;

        $username = $user; //=$_SESSION['username'];

        
        $conn = connect();

        $q_follow="SELECT `userID` FROM `followers` WHERE `followerID`='$username'";
        $follow=$conn->query($q_follow);
        
        $q_post="SELECT * FROM `posts` WHERE `userID` IN ($q_follow) OR `userID`='$username' ORDER BY `imageID` DESC LIMIT $number_of_posts OFFSET $offset";
        $r_post = $conn->query($q_post);

        while($post = $r_post->fetch_assoc()){
            $posts_loaded_n++;
            $post_picture=$post['imageID']; //to .webp
            //$post_picture="../img/posts/" . $post_picture . ".jpg";
            $post_user=$post['userID'];
            $post_title=$post['caption'];
            $post_date=$post['dateOfUpload'];
            
            post_html($post_user, $post_title, $post_picture, $post_date);
        }
        disconnect($conn);
        
        return $posts_loaded_n;
    }

    

    $post_n = 5;

    $user = $_GET['user'];
    $load = (int) $_GET['load'];

    switch ($user){
        default:
            if (load_feed_follow($load, $post_n, $user) >= $post_n){
                //quote_html($load);
            } else {
                // tech_html('End Of Feed<span id="eof"></span>');
                html_eof();
            }   
            
            break;

        
        case "ALL":
            if (load_feed_full($load, $post_n, $user) == $post_n){
                //quote_html($load);
            } else {
                //tech_html('End Of Feed<span id="eof"></span>');
                html_eof();
            }   
            break;
    }
?>