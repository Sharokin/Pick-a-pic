<?php 
session_start();
// include('connection.php');

// include('script_load_feed.php');

if (!isset($_SESSION['username']))
{
    header("Location:login.php");
}
?>

<!--SHAROKIN-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pick your Pic - Main Feed</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="../js/navbar_injection.js"></script>
    <link rel="icon" type="image/icon" href="../img/logo.png">
    <link rel="stylesheet" type="text/css" href="../style/main.css?v=<?php echo time(); ?>">
</head>

<body>

    <nav>
        <!-- navbar goes here with js script -->
    </nav>

    <div class="center__section color3">
        <div class="welcome">
            <h1>WELCOME <?php echo "@". $_SESSION["username"] . "!"?></h1>
            <p>insert nice welcoming message here bla bla bla etc...</p>
            <h4>Following is some suggestions for you to start of with...</h4>
            <li>You could <a href="settings.php">add a profile picture</a></li></br>
            <li>or maybe you want to <a href="settings.php">add a little description of yourself</a></li></br>
            <li>or you could just <a href="upload.php">start by uploading pics to your feed :)</a></li>
        </div>
    </div>
</body>

</html>