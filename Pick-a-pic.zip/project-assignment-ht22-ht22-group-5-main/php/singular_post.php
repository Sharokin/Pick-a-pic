<?php 
session_start();
include('connection.php');

if(isset($_GET['id']))
{
    $image_id = $_GET['id'];
    $sqlStr = "SELECT userID,caption FROM posts WHERE imageID = '$image_id'";
    $execute = $connection->query($sqlStr);
    $row = $execute -> fetch_assoc();
    $user_id = $row['userID'];
    $caption = $row['caption'];

}else{
    header('Location:feed_main.php');
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <?php 
        if (isset($_SESSION['username']))
        {
            echo '<script type="text/javascript" src="../js/navbar_injection.js"></script>';
        }
    ?>
    <link rel="stylesheet" type="text/css" href="../style/main.css?v=<?php echo time(); ?>">
    <title>Pick a Pic - Single Post</title>
</head>

<body>
    <div class="single__post__body__container">

        <nav>
            <!-- navbar goes here with js script -->
        </nav>


        <div class="post__container">

            <div class="single__post">

                <div class="post__image__container">
                    <img src="../img/posts/<?php echo $_GET['id']; ?>.webp" alt="">
                </div>

                <div class="post__info__container">

                    <div class="img__user">
                        <div class="img__user__info">
                            <?php
                                

                                $sqlStr = "SELECT * FROM users WHERE username='$user_id'";
                                $execute = $connection->query($sqlStr);
                        
                                $row = $execute ->fetch_assoc();

                                $fullname = $row['fullname'];
                                $bio = $row['bio'];
                                $pfp_path = $row['profile_img_path'];

                    
                            ?>
                            <img src="<?php 

                                        if(empty($pfp_path))
                                        {
                                            echo '../img/icons/default-icon-temp2.png';
                                        }else{
                                            echo $pfp_path;
                                        }


                                        ?>" alt="">
                            <a href=<?php echo "'profile.php?username=".$user_id."'"; ?>>@<?php echo $user_id; ?></a>
                        </div>

                        <?php 
                        if(isset($_SESSION['username']))
                        {
                            if($_SESSION['username']==$user_id)
                        {
                            echo "<a href='../php/delete_post.php?id=$image_id' id='post__delete__link'>Delete Post</a>";
                        }
                        }
                        
                        
                        ?>
                    </div>

                    <div class="post__comment__sec__container">
                        <div class="caption__container">
                            <p class="caption__txt">
                                <a class="caption__username" href="../php/profile.php?username=<?php echo $user_id; ?>">
                                    <?php echo $user_id; ?>:&nbsp;
                                </a>
                                <?php echo $caption;?>
                            </p>
                        </div>

                        <div class="post__comment__section" id="post__comment__section">
                        </div>
                    </div>



                    <div class="post__likes">
                    </div>
                    <?php 
                     echo '<input id="hidden_postID" type="hidden" name="id" value="'.$_GET['id'].'">';
                    if(isset($_SESSION['username']))
                    {
                        echo  '<div class="post__comment">';
                        echo '<form id="comment__form" class="comment__form">';
                        echo '<input id="hidden_postID" type="hidden" name="id" value="'.$_GET['id'].'">';
                        echo '<input type="hidden" id="hidden_userID" name="userID" value="'.$_SESSION['username'].'">';
                        echo '<textarea id="comment__textarea" class="comment__textarea" name="comment" id="comment"
                            placeholder="Type your comment"></textarea>
                        <button type="submit" id="comment__btn" class="comment__btn" disabled>Post</button>';
                        echo '</form>';
                        echo '</div>';
                    }

                    ?>
                </div>

            </div>

        </div>

    </div>
    </div>



    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script src="../js/single_post.js?v=<?php echo time(); ?>"></script>
    <script src="../js/comment_ajax.js?v=<?php echo time(); ?>"></script>
</body>

</html>