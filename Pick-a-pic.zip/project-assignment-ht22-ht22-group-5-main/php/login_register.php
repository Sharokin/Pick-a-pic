<?php
session_start();
include ("connection.php");
if(isset($_SESSION['username']))
{
    header("Location:feed_main.php");
}

$username = $password = $email = $fullName = $passwordConfirm = "";


$check = true;





if (isset($_POST['submit']))
{
    $passwordConfirm = $_POST['confirmPass'];


    if (!empty($_POST['email']))
    {
        if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
        {
            $email = $_POST['email'];
        }else{
            echo "<script>alert('Email not VALID!')</script>";
            $check = false;
        }
    }else{
        echo "<script>alert('Type in your Email!')</script>";
        $check = false;
    }


    if (!empty($_POST['username']))
    {
        $username = $_POST['username'];
    }else{
        echo "<script>alert('Type in your username')</script>";
        $check = false;
    }

    
    if (!empty($_POST['fullname']))
    {
        $fullName = $_POST['fullname'];
    }else{
        echo "<script>alert('Type in your Full Name')</script>";
        $check = false;
    }



    if (strlen($_POST['password'])>=6)
    {
        $password = $_POST['password'];
        $encryptedPass = password_hash($password, PASSWORD_BCRYPT);
    }else{
        echo "<script>alert('Password needs to be 6 characters or more.')</script>";
        $check = false;
    }

  



    if($check){

        $checkSql = "SELECT * FROM users WHERE username = '$username'";
        $execute = $connection->query($checkSql);

        if ($execute->num_rows > 0) {
            echo "<script>alert('Username taken!')</script>";
        } else{

        $checkSql = "SELECT * FROM users WHERE email = '$email'";
        $execute = $connection->query($checkSql);

        if ($execute->num_rows > 0) {
            echo "<script>alert('Email already taken!')</script>";
        }else {
            if($passwordConfirm != $password){
                echo "<script>alert('Passwords do not match!')</script>";
            }else{
                $sqlPrep = $connection->prepare("INSERT INTO users (email,fullname,username,password) values (?,?,?,?);");

                $sqlPrep->bind_param("ssss",$email, $fullName, $username, $encryptedPass);
                if ($sqlPrep->execute())
                {
                    $_SESSION["username"] = $username;
                    header("Location:settings.php");
                    // header("Location:welcome.php");
                }else{
                    die("Error! " . $connection ->error);
                }
            }
            }
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/registrate.css?v=<?php echo time(); ?>">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <link rel="icon" type="image/icon" href="../img/icons/logo.png">
    <title>Pick a Pic - Sign Up</title>
</head>

<body>
    <div class="main__reg__container">
        <section class="logo__section">
            <div class="logo__container">
                <img src="../img/icons/logo.png" alt="logo" id="logo__img">
            </div>
        </section>


        <div class="signup__form__container">
            <div class="signup__label__container">
                <h1>Sign Up</h1>
            </div>
            <form id="reg__form" action="" method="post" class="signup__form">
                <div class="form__element">
                    <div class="form__container">
                        <input name="email" type="text" required class="form__input">
                        <span class="error_msg email_err"></span>
                        <label class="form__label">Email</label>
                    </div>
                </div>

                <div class="form__element">
                    <div class="form__container">
                        <input name="fullname" type="text" required class="form__input">
                        <label class="form__label">Full Name</label>
                    </div>
                </div>

                <div class="form__element">
                    <div class="form__container">
                        <input name="username" type="text" required class="form__input">
                        <label class="form__label">Username</label>
                    </div>
                </div>

                <div class="form__element">
                    <div class="form__container">
                        <input name="password" type="password" required class="form__input">
                        <label class="form__label">Password</label>
                    </div>
                </div>
                <div class="form__element">
                    <div class="form__container">
                        <input name="confirmPass" type="password" required class="form__input">
                        <label class="form__label">Confirm Password</label>
                    </div>
                    <div class="signup__link__container">
                        <p>Already have an account?&nbsp;<a href="login.php">Log In</a></p>
                    </div>
                </div>

                <div class="form__element">
                    <div class="form__submit__container">
                        <button type="submit" id="" name="submit" class="form__submit">Sign Up</button>
                    </div>
                </div>
            </form>
        </div>

    </div>

    <script src="/js/registrate.js"></script>
</body>

</html>