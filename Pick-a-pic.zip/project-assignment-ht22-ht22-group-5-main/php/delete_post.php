<?php
include ("connection.php");

session_start();
if(!isset($_SESSION['username']))
{
    header("Location: index.php");
}
    $user = $_SESSION['username'];
    $id = $_GET['id'];
    $sqlStr = "DELETE FROM posts WHERE imageID = $id";
    $execute = $connection->query($sqlStr);

    header("Location:profile.php?username=$user");
?>