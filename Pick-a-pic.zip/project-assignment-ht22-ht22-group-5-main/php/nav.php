<?php  session_start(); include('connection.php');
	if (!isset($_SESSION['username'])) {
	header("Location:login.php");
	}
                    if (isset($_SESSION['username']))
                    {
                        $username = $_SESSION['username'];
                        $sqlStr = "SELECT profile_img_path FROM users WHERE username='$username'";
                        $execute = $connection->query($sqlStr);
                        $row = $execute ->fetch_assoc();
                        $pfp_path = $row['profile_img_path'];
                    }
?>

<nav id="nav__js">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<script src="../js/nav_scroll.js"></script>
    <link rel="stylesheet" href="../style/nav.css?6">
    <div class="nav__sticky">
        <div class="nav__container">
			<div class="nav__logo__container">
				<a href="feed_main.php"><img alt="logo" src="../img/icons/logo.png" class="nav__logo"></a>
			</div>
	        
	        <div class="nav__search__container">
		        <div class="nav__search">
			        <div class="nav__search__input">
				        <a href="" target="_blank" hidden></a>
				        <input type="text" placeholder="Search.." id="search-input">
				        <div class="nav__search__input_autocomplete" id="results">
					        <!-- Javascript loaded here! -->
				        </div>
			        </div>
		        </div>
	        </div>
	        
            <script src="../js/search_insert.js"></script>

	        <div class="nav__icon__container__flex">
		        <div class="nav__icon__container">
			        <ul>
				        <li>
					        <a href="feed_main.php" id="home"><img alt="home" src="../img/icons/feed-icon.png" class="nav__icon"></a>
				        </li>
				        <li>
					        <a href="upload.php" id="upload"><img alt="upload" src="../img/icons/upload-icon.png" class="nav__icon"></a>
				        </li>
				        <li>
					        <div class="nav__dropdown">
						        <a href="<?php echo 'profile.php?username='.$_SESSION['username']; ?>"
						           id="profile__picture"><img class='nav__icon' id='dropdown' src="<?php

							        if(empty($pfp_path))
							        {
								        echo '../img/icons/default-icon-temp2.png';
							        }else{
								        echo $pfp_path;
							        }
							        ?>" alt="profile_pic.jpg"></a>
						        <div class="nav__dropdown__content">
							        <a href="<?php echo 'profile.php?username='.$_SESSION['username']; ?>" id="profile"><img alt="profile" src="../img/icons/profile.png" class="nav__dropdown__icon">Profile</a>
							        <a href="settings.php" id="settings"><img alt="settings" src="../img/icons/cog.png" class="nav__dropdown__icon">Settings</a>
							        <a href="logout.php" id="logout"><img alt="logout" src="../img/icons/logout.png" class="nav__dropdown__icon">Logout</a>
						        </div>
					        </div>
				        </li>
			        </ul>
		        </div>
	        </div>
	        <div class="nav__chocolate">
		        <a href="#" id="chocolate__button"><img class='nav__icon' src="../img/icons/chocolate.png" alt="chocolate"></a>
	        </div>
        </div>
    </div>

	<script src="../js/menu_toggle.js?6"></script>
</nav>
