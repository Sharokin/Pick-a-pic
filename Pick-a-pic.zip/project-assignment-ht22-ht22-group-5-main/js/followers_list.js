
var path = window.location.search.split('=');
var username = path[1];

async function followersJson (){
    // const data = await fetch('http://localhost/project-assignment-ht22-ht22-group-5/php/followers.php?username='+username);
    const data = await fetch('../php/followers.php?username='+username);
    const jsonData = await data.json();
    return jsonData;
    
}



const followers = followersJson();
let allFollowersDiv = document.getElementById("all__followers");

followers.then((result)=>{

    for(let i = 0; i < result.length; i++) {
        let obj = result[i];
        let follower = obj.followerID;
    
        let followerDiv = document.createElement('div');
        followerDiv.classList.add('follower');
        let followerUsernameDiv = document.createElement('div');
        followerUsernameDiv.classList.add('follower__username');
        let followerLink = document.createElement('a');
        followerLink.setAttribute("href", "profile.php?username="+follower);
        followerLink.innerHTML = "@"+follower;   
        followerUsernameDiv.append(followerLink);
        followerDiv.append(followerUsernameDiv);
        allFollowersDiv.append(followerDiv);
    }
});

