
var path = window.location.search.split('=');
var username = path[1];

async function followingJson (){
    const data = await fetch('../php/following.php?username='+username);
    const jsonData = await data.json();
    return jsonData;
    
}



const following = followingJson();
let allFollowingDiv = document.getElementById("all__following");
following.then((result)=>{

    for(let i = 0; i < result.length; i++) {
        let obj = result[i];
        let followingP = obj.userID;
    
        let followingDiv = document.createElement('div');
        followingDiv.classList.add('following');
        let followingUsernameDiv = document.createElement('div');
        followingUsernameDiv.classList.add('following__username');
        let followingLink = document.createElement('a');
        followingLink.setAttribute("href", "profile.php?username="+followingP);
        followingLink.innerHTML = "@"+followingP;   
        followingUsernameDiv.append(followingLink);
        followingDiv.append(followingUsernameDiv);
        allFollowingDiv.append(followingDiv);
    }
});