const autoComplete = document.querySelector(".nav__search__input");
const searchBar = autoComplete.querySelector("input");
const suggestionList = autoComplete.querySelector(".nav__search__input_autocomplete");

searchBar.onkeyup = (e)=>{
    let inputData = e.target.value;
    if (inputData) {
        if(inputData.length < 3 || inputData.startsWith(" ")) {
            autoComplete.classList.remove("active");
            return;
        }
        updateUsers(inputData);
    }
    else {
        autoComplete.classList.remove("active");
    }
}

function updateUsers(user) {
    $.ajax({
        data: {user: user},
        url: 'search_users.php',
        type: 'POST',
        success: function(data){
            let retval = [];
            let parsed = JSON.parse(data);
            for(let i = 0; i < parsed.length; i++) {
                retval[i] = Object.values(parsed[i]);
            }
            if(retval.length === 0) {
                return;
            }
            retval = retval.map((data)=>{
                return data = `<li>${data}</li>`;
            });
            autoComplete.classList.add("active");
            showSuggestions(retval);
            let listDividers = suggestionList.querySelectorAll("li");
            for (let i = 0; i < listDividers.length; i++) {
                let element = listDividers[i];
                listDividers[i].onclick = function () {
                    searchBar.value = element.textContent;
                    autoComplete.classList.remove("active");
                    let xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function (){
                        if(this.readyState === 4 && this.status === 200) {
                            location.href = 'profile.php?username=' + element.textContent;
                        }
                    }
                    xhttp.open("POST", "profile.php", true);
                    xhttp.send(this);
                }
            }
        }
    });
}

function showSuggestions(list) {
    let listData;
    let userValue;
    if (!list.length) {
        userValue = searchBar.value;
        listData = `<li>${userValue}</li>`;
    }
    else {
        listData = list.join('');
    }
    suggestionList.innerHTML = listData;
}

