

function drawImageScaled(image, myContext, myCanvas) {


    let canvas = myContext.canvas;

    let orginal_width = 1024;
    
    canvas.width = orginal_width * image.width/image.height;
    
    //myContext.clearRect(0, 0, canvas.width, canvas.height);
    myContext.drawImage(image, 0, 0, image.width, image.height, 0, 0, canvas.width, canvas.height);
    
    let imageData = myCanvas.toDataURL('image/webp', 0.8);
    document.getElementById('base64').value = imageData; 
}

const myCanvas = document.getElementById("test_canvas");
const myContext = myCanvas.getContext("2d");

const preview = document.getElementById('input_file');


//Inlagt 28/10
const loadImage = function (url, myContext) {
    var img = new Image();
    img.src = url

    let canvas = myContext.canvas;

    let orginal_width = 1024;
    let orginal_height = 1024;
    
    //canvas.width = orginal_width * img.width/img.height;
    //canvas.height = orginal_height * img.height/img.width;

    img.onload = function () { 
      myContext.drawImage(img, 0, 0, img.width, img.height, canvas.width/4, canvas.height/4, img.width/2, img.height/2);
    }
}

window.onload = loadImage("../img/icons/camera.png", myContext);
//Inlagt 28/10


preview.addEventListener('change', event => {
    const file = event.target.files[0];
    

    const reader = new FileReader();
    reader.addEventListener('load', event => {
        const image = new Image();
        image.src = event.target.result;
        image.onload = () => {
            drawImageScaled(image, myContext, myCanvas);
        };
    });
    reader.readAsDataURL(file);
});