document.querySelector('#followers__link').onclick = () =>{
    
        document.querySelector('.followers__cover').style.visibility = "visible";
        
    
}

document.querySelector('#close__follower__popup').onclick = () =>{
    document.querySelector('.followers__cover').style.visibility = "hidden";
    ;
}



document.querySelector('#following__link').onclick = () =>{
    
    document.querySelector('.following__cover').style.visibility = "visible";
    

}

document.querySelector('#close__following__popup').onclick = () =>{
    
    document.querySelector('.following__cover').style.visibility = "hidden";
}



/*itemGrid = document.querySelector('.grid__item');
itemGrid.addEventListener('mouseover', function() {
    document.querySelector(".pop__up__description").style.transform="translateY(-100%)";
    document.querySelector(".pop__up__description").style.transition=" all 0.5s"
    console.log("yo")
});

itemGrid.addEventListener('mouseleave', function() {
    document.querySelector(".pop__up__description").style.transform="translateY(100%)";
    document.querySelector(".pop__up__description").style.transition=" all 0.5s"
    console.log("yo")
}); */