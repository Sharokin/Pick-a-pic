
var pathArray = window.location.search.split('=');
var username = pathArray[1];

async function imagesJson (){
    const data = await fetch('../php/profile_images.php?username='+username);
    const jsonData = await data.json();
    return jsonData;
    
}



const images = imagesJson();

let imagesSection = document.getElementById('images__section');


images.then((result)=>{

    if(result.length > 0)
    {
        let imagesGrid = document.createElement('div');
        imagesGrid.classList.add('images__grid');
        imagesGrid.id = 'profile_images_grid';
        imagesSection.append(imagesGrid);

        for(let i = result.length-1; i >= 0; i--) {
            let obj = result[i];
            let imageNum = obj.imageID;
            let imageCaption = obj.caption;

            let gridItem = document.createElement('div');
            gridItem.classList.add('grid__item');
            let imagesPost = document.createElement('div');
            imagesPost.classList.add('images__post');
            let imageLink = document.createElement('a');
            imageLink.href = "../php/singular_post.php?id="+imageNum;
            let image = document.createElement('img');
            image.setAttribute("src", "../img/posts/"+imageNum+".webp");
            imageLink.append(image);

            let descWrapper = document.createElement('a');
            descWrapper.href = "../php/singular_post.php?id="+imageNum;
            descWrapper.style.display = 'block';
            descWrapper.classList.add('pop__up__desc__wrap');
            let popUpDesc = document.createElement('div');
            let popUpLikes = document.createElement('div');
            popUpDesc.classList.add('pop__up__description');
            popUpLikes.classList.add('pop__up__likes');
            let likes = document.createElement('p');
            likes.innerHTML ="";    // "101 likes";
            let caption = document.createElement('p');
            caption.innerHTML = ""+imageCaption;
            caption.classList.add('pop__up__desc__caption');
            
            popUpLikes.append(likes);
            popUpDesc.append(popUpLikes);
            popUpDesc.append(caption);
            descWrapper.append(popUpDesc);
    
            imagesPost.append(imageLink);
            imagesPost.append(descWrapper);
            gridItem.append(imagesPost);
            imagesGrid.append(gridItem);
        }
    }else{
        let noPostsDiv = document.createElement('div');
        noPostsDiv.classList.add('no__current__posts');
        let noPosts = document.createElement('h1');
        noPosts.innerHTML ="No posts yet";
        noPostsDiv.append(noPosts);
        imagesSection.append(noPostsDiv);
    }
});

