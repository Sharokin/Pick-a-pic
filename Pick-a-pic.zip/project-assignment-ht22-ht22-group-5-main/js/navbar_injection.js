$(document).ready(function(){
    $('nav').load("../php/nav.php");
});