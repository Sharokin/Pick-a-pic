const chocolate = document.querySelector(".nav__chocolate");
const icon_container = document.querySelector(".nav__icon__container__flex");
const search__container = document.querySelector(".nav__search__container");

chocolate.addEventListener("click", chocolate_click);

const profile = document.getElementById("profile__picture");
let profile_href = document.getElementById("profile").getAttribute("href");

function chocolate_click() {
    let display = getComputedStyle(icon_container).display;
    if (display === "none") {
        search__container.style.display = "none";
        icon_container.style.display = "flex";

        profile.setAttribute("href", "#");
        profile.href = "#";
    }
    else {
        search__container.style.display = "flex";
        icon_container.style.display = "none";
    }
}

window.matchMedia("(max-width: 768px)").addEventListener("change", (e)=> {
    if (e.matches) {
        search__container.style.display = "flex";
        icon_container.style.display = "none";

        profile.setAttribute("href", "#");
        profile.href = "#";
    }
    else {
        search__container.style.display = "flex";
        icon_container.style.display = "flex";

        profile.setAttribute("href", profile_href);
        profile.href = profile_href;
    }
});






