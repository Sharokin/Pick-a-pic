$(document).ready(function(){

    function getComments(){
        let postID = $("#hidden_postID").val();
        $.ajax({
            data: {postID: postID},
            url: 'get_comments.php',
            type: 'POST',
            success: function(data){
                $("#post__comment__section").html(data);
            }
        });
    }

    getComments();

    $("#comment__btn").on("click", function(e){
        e.preventDefault();
        let userID = $("#hidden_userID").val();
        let postID = $("#hidden_postID").val();
        let comment = $("#comment__textarea").val();

        $.ajax({
            url: 'post_comment.php',
            type: 'POST',
            data: {userID: userID, postID: postID, comment: comment},
            success: function(data){
                if (data == 1) {
                    getComments();
                    $('#comment__form').trigger('reset');
                    $('#comment__btn').attr("disabled","disabled");
                }
            }
        });
    });
});

