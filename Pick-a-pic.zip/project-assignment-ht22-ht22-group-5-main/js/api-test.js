
async function fetchFromAPI(/*eventuella variabler med kanske valda ord från användares kommentarer*/){
    
    const quoteText = document.getElementById("quote");
    const person = document.getElementById("author");

    const url = new URL("https://motivational-quote-api.herokuapp.com/quotes/random");

    const response = await fetch(url);

    const quotes = await response.json();

    console.log(quotes);
    quoteText.innerHTML = quotes.quote;
    person.innerHTML = " - " + quotes.person;
}
