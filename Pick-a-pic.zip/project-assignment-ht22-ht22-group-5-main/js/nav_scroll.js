const navbar = document.querySelector(".nav__sticky");
const dropdown = document.querySelector(".nav__dropdown");
const searchbar = document.querySelector(".nav__search__input");

const clientHeight = document.documentElement.clientHeight;
const clientThreshold = clientHeight - vh(10);

document.onmousemove = (e)=> {
    let input = document.getElementById("search-input").value;
    if(!(dropdown.matches(":hover") || searchbar.matches(":hover")) && !(input.length > 0)) {
        if (e.clientY > (clientHeight - clientThreshold) && window.scrollY === 0) {
            navbar.classList.remove("nav__scroll");
        }
        else {
            navbar.classList.add("nav__scroll");
        }
    }
}

document.onscroll = ()=> {
    let input = document.getElementById("search-input").value;
    if(input.length === 0) {
        if(window.scrollY > 0) {
            navbar.classList.add("nav__scroll");
        }
        else {
            navbar.classList.remove("nav__scroll");
        }
    }
}

function vh(percent) {
    let h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
    return (percent * h) / 100;
}