let textarea = document.getElementById('comment__textarea');
let submitBtn = document.getElementById('comment__btn');
function buttonControl(){
    let textareaVal = textarea.value;
    
    if(textareaVal.length>0)
    {   
        submitBtn.disabled = false;
    }else{
        
        submitBtn.disabled = true;
    }
}
textarea.addEventListener('keyup', ()=>{

    buttonControl();
})
