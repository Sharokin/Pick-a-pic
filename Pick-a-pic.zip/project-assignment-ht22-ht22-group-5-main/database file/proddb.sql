-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Värd: 127.0.0.1
-- Tid vid skapande: 24 okt 2022 kl 00:10
-- Serverversion: 10.4.24-MariaDB
-- PHP-version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `proddb`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `userID` varchar(20) NOT NULL,
  `postID` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumpning av Data i tabell `comments`
--

INSERT INTO `comments` (`id`, `userID`, `postID`, `comment`) VALUES
(1, 'Tom', 28, 'That was a nice tune'),
(2, 'sansa123', 28, 'I agree'),
(3, 'petar1234', 28, 'thx!'),
(4, 'Tom', 39, 'I won this time');

-- --------------------------------------------------------

--
-- Tabellstruktur `followers`
--

CREATE TABLE `followers` (
  `id` int(11) NOT NULL,
  `userID` varchar(20) NOT NULL,
  `followerID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumpning av Data i tabell `followers`
--

INSERT INTO `followers` (`id`, `userID`, `followerID`) VALUES
(1, 'Tom', 'jonsand'),
(3, 'Tom', 'nedstork'),
(4, 'Tom', 'sansa123'),
(5, 'petar1234', 'sansa123'),
(10, 'sansa123', 'petar1234'),
(11, 'jonsand', 'petar1234'),
(15, 'petar1234', 'Tom');

-- --------------------------------------------------------

--
-- Tabellstruktur `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `userID` varchar(20) NOT NULL,
  `post` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellstruktur `posts`
--

CREATE TABLE `posts` (
  `userID` varchar(20) NOT NULL,
  `imageID` int(11) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `dateOfUpload` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumpning av Data i tabell `posts`
--

INSERT INTO `posts` (`userID`, `imageID`, `caption`, `dateOfUpload`) VALUES
('Tom', 20, 'What a nice vacation that was...', '2022-10-23 22:34:31'),
('petar1234', 21, 'good day at work, we really showed that css who\'s boss', '2022-10-23 22:38:41'),
('petar1234', 22, 'Did a new personal best at the gym today!', '2022-10-23 22:40:33'),
('sansa123', 23, 'that was some tasty pizza, I must say', '2022-10-23 22:44:31'),
('jonsand', 24, 'I made this in photoshop, promise', '2022-10-23 22:50:07'),
('Tom', 25, 'obligatory food picture on social media', '2022-10-23 22:52:28'),
('Tom', 26, '...and some tasty pastry', '2022-10-23 22:54:47'),
('sansa123', 27, 'chilling on the weekend in the backyard with my dog', '2022-10-23 22:59:34'),
('petar1234', 28, 'playing the guitar', '2022-10-23 23:01:41'),
('Tom', 29, 'out golfing with the boys', '2022-10-23 23:03:40'),
('petar1234', 30, 'What a view!', '2022-10-23 23:05:56'),
('Tom', 31, 'after I lost at golf I decided to lose some in chess', '2022-10-23 23:08:32'),
('jonsand', 32, 'south of the wall', '2022-10-23 23:10:51'),
('Tom', 33, 'out contemplating life...', '2022-10-23 23:12:23'),
('petar1234', 34, 'easy', '2022-10-23 23:15:45'),
('sansa123', 35, 'out for a stroll north of the fence', '2022-10-23 23:20:56'),
('sansa123', 36, 'much warmer', '2022-10-23 23:22:55'),
('nedstork', 37, 'chess is a wonderful game', '2022-10-23 23:27:27'),
('jonsand', 38, 'cartoonishly goodlooking', '2022-10-23 23:30:47'),
('Tom', 39, 'one more try', '2022-10-23 23:34:03'),
('petar1234', 40, 'going on vacation soon', '2022-10-24 00:08:10');

-- --------------------------------------------------------

--
-- Tabellstruktur `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_img_path` varchar(255) DEFAULT NULL,
  `fullname` varchar(30) DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumpning av Data i tabell `users`
--

INSERT INTO `users` (`username`, `email`, `password`, `profile_img_path`, `fullname`, `bio`) VALUES
('jonsand', 'jonsnow@gmail.com', '$2y$10$Kc3S.CeSebQYEWzY.oFYre9gS/R4Q/Oj/H/Fo/PNCjtcPGavDG4dS', '../img/profile/jonsand.jpg', 'Jonni Sand', 'Hi! I\'m Jonni. You might know me from such shows as [redacted] and [redacted].'),
('nedstork', 'nedstart@gmail.com', '$2y$10$all0dYNHruHJMicUn1RUMe40omzdkveDlncFYgjS6z4mPV5s/IYn.', '../img/profile/nedstork.jpg', 'Eddy Stork', 'I\'m headless Ed, nothing more can be said'),
('petar1234', 'petardjukic23@gmail.com', '$2y$10$SfHK6WVFzZoEFKoCkWmvr.31S1jUslcHkW1lgVm8W5hpIajgBBa7q', '../img/profile/petar1234.jpg', 'Petar Djukic', 'Hello! I have made this page! And a login page, and a signup page, and follow and unfollow function, and following/followers lists! '),
('sansa123', 'sansa@gmail.com', '$2y$10$1J/ZfmQejaT3Sl/kb0N15e/hrsNzMz2R0UBxRT77XWkN7SA0jEWfi', '../img/profile/sansa123.jpg', 'Sansa Stork', 'I\'m Sansa Stork from the hit show, Competitions for the Seat'),
('Tom', 'test@gmail.com', '$2y$10$KQeEkjzGLgcSFUBIwpeAge/hvDJUMuaO.JntkfidOEBYIphYG1ISy', '../img/profile/Tom.jpg', 'TJ', 'Hi, hope you like my pictures');

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postID` (`postID`);

--
-- Index för tabell `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID` (`userID`),
  ADD KEY `followerID` (`followerID`);

--
-- Index för tabell `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userID` (`userID`),
  ADD KEY `post` (`post`);

--
-- Index för tabell `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`imageID`),
  ADD KEY `user_FK_1` (`userID`);

--
-- Index för tabell `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT för tabell `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT för tabell `posts`
--
ALTER TABLE `posts`
  MODIFY `imageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Restriktioner för dumpade tabeller
--

--
-- Restriktioner för tabell `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comment_FK_1` FOREIGN KEY (`postID`) REFERENCES `posts` (`imageID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restriktioner för tabell `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followes_FK_1` FOREIGN KEY (`userID`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `followes_FK_2` FOREIGN KEY (`followerID`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restriktioner för tabell `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_FK_1` FOREIGN KEY (`userID`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `likes_FK_2` FOREIGN KEY (`post`) REFERENCES `posts` (`imageID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restriktioner för tabell `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `user_FK_1` FOREIGN KEY (`userID`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
