--CREATE TABLE users (
--	username varchar(20) PRIMARY KEY,
--	email varchar(50) NOT NULL UNIQUE,
--	password varchar(20) NOT NULL,
--	profile_img_path varchar(255),
--	fullname varchar(20) NOT NULL,
--	bio varchar(255)
--	);

--CREATE TABLE posts (
--	userID varchar(20) FOREIGN KEY REFERENCES users(username),
--	imageID int IDENTITY(1,1) PRIMARY KEY,
--	caption varchar(255),
--	dateOfUpload datetime2 DEFAULT(getdate()),
--	);

--CREATE TABLE comments (
--	id int PRIMARY KEY,
--	userID varchar(20),
--	postID int FOREIGN KEY REFERENCES posts(imageID),
--	comment varchar(max) NOT NULL
--	);

--CREATE TABLE likes (
--	id int PRIMARY KEY,
--	userID varchar(20) FOREIGN KEY REFERENCES users(username),
--	post int FOREIGN KEY REFERENCES posts(imageID)
--);

--CREATE TABLE followers (
--	id int PRIMARY KEY,
--	userID varchar(20) FOREIGN KEY REFERENCES users(username),
--	followerID varchar(20) FOREIGN KEY REFERENCES users(username)
--);